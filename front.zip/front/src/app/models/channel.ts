export class Channel {
  title: string;
  summary?: string;
  id: number;
  follwers?: number;
  rule?: string;
  authors: any[];
  link: string;
}

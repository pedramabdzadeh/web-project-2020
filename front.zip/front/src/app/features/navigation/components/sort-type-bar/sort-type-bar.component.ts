import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sort-type-bar',
  templateUrl: './sort-type-bar.component.html',
  styleUrls: ['./sort-type-bar.component.scss']
})
export class SortTypeBarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  sort(following: string) {
    
  }
}
